# Extensions Generic (Netsky Fork) Repo Index

## THIS IS A FORKED REPO OF THE ORIGINAL PAPERBACK GENERIC

[Github Repo](https://github.com/TheNetsky/extensions-generic)
<br>
Join the [Discord](https://discord.gg/rmf6jQpMU9) for support and more sources!

## Current Repo

| Source Type | Description |          Link |
| ---        |    ----   |         --- |
| Madara      | Updated Madara sources for Paperback      | [Click me!](https://thenetsky.github.io/extensions-generic/madara/)    |
| MangaBox   | Updated MangaBox sources for Paperback     |  [Click me!](https://thenetsky.github.io/extensions-generic/mangabox/)    |
| NepNep   | Updated NepNep sources for Paperback     |  [Click me!](https://thenetsky.github.io/extensions-generic/nepnep/)    |
| Guya   | Updated Guya sources for Paperback     |  [Click me!](https://thenetsky.github.io/extensions-generic/guya/)    |
| Bentai (NSFW)  | Updated Bentai sources for Paperback     |  [Click me!](https://thenetsky.github.io/extensions-generic/bentai/)    |
| Genkan  | Updated Genkan sources for Paperback     |  [Click me!](https://thenetsky.github.io/extensions-generic/genkan/)    |
